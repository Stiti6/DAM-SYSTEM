<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - StormSignal</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('background.jpg'); /* Change this to your image path */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-container {
            background: rgba(0, 0, 0, 0.5);
            padding: 40px;
            border-radius: 10px;
            width: 300px;
            text-align: center;
            color: white;
        }

        .login-container h2 {
            margin-bottom: 20px;
        }

        .input-field {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            background: #fff;
            color: #333;
        }

        .login-button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: #45a049;
        }

        .register-link {
            margin-top: 10px;
            color: #ccc;
        }

        .register-link a {
            color: #fff;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="index-link">
            <h2>Login to Storm Signal</h2>
                <form action="index.html" method="post">
                    <input type="text" name="username" class="input-field" placeholder="Username" required>
                    <input type="email" name="email" class="input-field" placeholder="Email ID" required>
                    <input type="Number" name="digit" class="input-field" placeholder="Password" required>
                    <!--<button type="submit" class="login-button"></button>-->
                    <button type="login" class="login-button"><a href="index.html">Login</a></button>
                </form>
            <div class="register-link">
                <p>Don't have an account? <a href="register.html">Register</a></p>
            </div>
        </div>
    </div>

        <script>
            document.getElementById('loginForm').addEventListener('submit', function (event) {
                const username = document.querySelector('input[name="username"]').value.trim();
                const email = document.querySelector('input[name="email"]').value.trim();
                const password = document.querySelector('input[name="digit"]').value.trim();
        
                if (username === '' || email === '' || password === '') {
                    alert('Please fill in all fields.');
                    event.preventDefault(); // Prevent form submission
                } else {
                    // Redirect to index.html
                    this.action = 'index.html';
                }
            });
        </script>
        
   

</body>
</html>